import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:interviewtask/model/firstmodel.dart';

class ProductProvider with ChangeNotifier {
  List<Product> _products = [];
  bool _isLoading = false;

  List<Product> get products => _products;
  bool get isLoading => _isLoading;

  // Fetch products from the API
  Future<void> fetchProducts() async {
    _isLoading = true;
    notifyListeners();

    final url = Uri.parse('https://dummyjson.com/products');
    try {
      final response = await http.get(url);
      final data = json.decode(response.body);
      final productData = data['products'] as List;

      _products = productData
          .map((item) => Product(
                title: item['title'],
                price: item['price'],
                thumbnail: item['thumbnail'],
                quantity: 0,
              ))
          .toList();

      _isLoading = false;
      notifyListeners();
    } catch (error) {
      _isLoading = false;
      notifyListeners();
      throw error;
    }
  }

  // Update the quantity of a product
  void updateQuantity(int index, int delta) {
    if (_products[index].quantity + delta >= 0) {
      _products[index].quantity += delta;
      notifyListeners();
    }
  }

  // Calculate the total quantity of all products
  int get totalQuantity {
    int total = 0;
    for (var product in _products) {
      total += product.quantity;
    }
    return total;
  }

  // Calculate total price of all products
  double get totalPrice {
    double total = 0.0;
    for (var product in _products) {
      total += product.price!*product.quantity;
    }
    return total;
  }
}