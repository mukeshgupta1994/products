// ignore_for_file: unused_local_variable

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class Firstcontroller extends ChangeNotifier {
  bool _isloading = false;
  String? _errorMessage;

  bool get isloading => _isloading;
  String? get errorMessage => _errorMessage;

  Future<bool> login(
    String username,
    String password,
  ) async {
    _isloading = true;
    _errorMessage = null;
    notifyListeners();
    final url = Uri.parse("https://dummyjson.com/auth/login");
    try {
      final response = await http.post(url,
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({
            'username': username,
            'password': password,
            'expiresInMins': 30
          }));
      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        _isloading = false;
        notifyListeners();
        return true;
      } else {
        _errorMessage = "Failed Login";
        _isloading = false;
        notifyListeners();
        return false;
      }
    } catch (error) {
      _errorMessage = "An error occurred : $error";
      _isloading = false;
      notifyListeners();
      return false;
    }
  }
}
