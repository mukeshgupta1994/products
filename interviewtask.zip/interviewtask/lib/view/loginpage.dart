
import 'package:flutter/material.dart';
import 'package:interviewtask/controller/firstcontroller.dart';
import 'package:interviewtask/view/homepage.dart';
import 'package:provider/provider.dart';

class Loginpage extends StatefulWidget {
  const Loginpage({super.key});

  @override
  State<Loginpage> createState() => _LoginpageState();
}

class _LoginpageState extends State<Loginpage> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  void _login(BuildContext context) async {
    final username = _usernameController;
    final password = _passwordController;
    if (username.text.isEmpty || password.text.isEmpty) {
      return;
    }

    final success = await Provider.of<Firstcontroller>(context, listen: false)
        .login(username.text, password.text);

    if (success) {
      Navigator.pushReplacement(
          context, MaterialPageRoute(builder: (context) => ProductScreen()));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          centerTitle: true,
          title: const Text("Login"),
        ),
        body: Padding(
          padding: const EdgeInsets.all(10),
          child: Consumer<Firstcontroller>(
              builder: (context, Loginprovider, child) {
            return Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextField(
                  controller: _usernameController,
                  decoration: const InputDecoration(labelText: "Username"),
                ),
                const SizedBox(
                  height: 10,
                ),
                TextField(
                  controller: _passwordController,
                  decoration: const InputDecoration(labelText: "Username"),
                ),
                const SizedBox(
                  height: 10,
                ),
                ElevatedButton(
                  onPressed:
                      Loginprovider.isloading ? null : () => _login(context),
                  child: const Text("Login")
                ),
                  
              ],
            );
          }),
        ));
  }
}
