package com.example.interviewtask

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
